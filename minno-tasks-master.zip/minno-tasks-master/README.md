# minno-tasks
Reusable tasks for Minno,js (mostly implicit measures)

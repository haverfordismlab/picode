In this example, you can find scripts for a few different indirect evaluation measures. These scripts use Minno.js and Datapipe for running a web study for free.

To learn more about how to adapt these scripts and use them in your own studies, see [this blog post](https://minnojs.github.io/blog/2023/11/01/running-project-implicits-iat-on-your-own/), 
and the [Minno.js documentation](https://minnojs.github.io/). You can also ask questions in Minno.js [Google Forum](https://groups.google.com/g/minnojs/).

[Run the example](https://baranan.github.io/minno-tasks/studies/datapipe.indirects/exampleiat.html).

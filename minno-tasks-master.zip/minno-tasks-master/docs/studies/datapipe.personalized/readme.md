This example is a personalized Single-Target IAT. Participants create their own ST-IAT stmuli. 

To learn more about how to adapt these scripts and use them in your own studies, see [this blog post](https://minnojs.github.io/blog/2023/11/01/running-project-implicits-iat-on-your-own/), 
and the [Minno.js documentation](https://minnojs.github.io/). You can also ask questions in Minno.js [Google Forum](https://groups.google.com/g/minnojs/).

[Run the example](https://baranan.github.io/minno-tasks/studies/datapipe.personalized/exampleiat.html).
